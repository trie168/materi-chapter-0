# Hacktiv8 Phase 0 is Over: That's a wrap!

Kami akan merangkum semua laporan kegiatan kamu dan menyimpulkan hasilnya, yang akan kita berikan ke masing-masing kamu.

Termasuk juga:

- Showcases
- Blog Post Collection
- Activity Evaluation
- Final Activity Evaluation
