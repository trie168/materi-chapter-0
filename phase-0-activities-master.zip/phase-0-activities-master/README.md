# HACKTIV8 Phase 0 Activities

Phase 0 adalah aktivitas yang mempersiapkan murid untuk mampu memahami dan masuk ke dalam Phase 1 Program
Full-Stack JavaScript Development Course di HACKTIV8. Repositori ini digunakan sebagai acuan untuk pembelajaran dan bersifat wajib untuk dipelajari dan dikerjakan untuk berkesempatan melanjutkan ke dalam Phase 1.

Materi di bagi ke dalam enam minggu, yang tiap minggu nya terdiri dari berbagai fokus materi. Kebanyakan dari
materi dan tantangan yang tertera pada repositori ini hanya dapat di akses oleh murid yang sedang aktif di dalam phase 0 batch program.

### [Week 1: Membuat Website Pertama Saya](./README-WEEK-1.md)
### [Week 2: Mengenal JavaScript](./README-WEEK-2.md)
### [Week 3: Mendalami JavaScript](./README-WEEK-3.md)
### [Week 4: Bermain Logic di JavaScript](./README-WEEK-4.md)
### [Week 5: Bermain Logic di JavaScript](./README-WEEK-5.md)
### [Week 6: Menguasai JavaScript ES6 dan Paradigma Programming](./README-WEEK-6.md)
