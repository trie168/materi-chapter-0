# Play Some Blockly Games

## Objectives

Blockly Games merupakan sekumpulan permainan edukatif yang mengajarkan programming. Tujuan aslinya dibuat untuk anak-anak. Namun kita bisa memanfaatkannya untuk melatih kemampuan logika. Sekaligus juga melihat alternatif lain belajar pemrograman. Anggaplah ini sebagai _having fun_ bagimu di samping materi serius yang lain.

## Directions

- ▢ Kunjungi <https://blockly-games.appspot.com>, lalu mainkan berbagai level berikut sesukamu:
  - Puzzle
  - Maze
  - Bird
  - Turtle
  - Movie
  - Pond

## References

- [Blockly on Google for Education](https://developers.google.com/blockly)
- [Scratch](https://scratch.mit.edu)
