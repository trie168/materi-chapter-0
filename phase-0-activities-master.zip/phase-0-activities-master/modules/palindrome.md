# Challenge !! Palindrome

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama palindrome. Palindrome adalah kata yang apabila urutan nya dibalik, akan menghasilkan string yang sama. Contohnya : katak, malam, dll.
Function tsb akan menerima sebuah parameter string, kemudian menghasilkan boolean true / false saja.
3. Kirim hasil code kamu dengan gist, dengan nama file : palindrome.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
