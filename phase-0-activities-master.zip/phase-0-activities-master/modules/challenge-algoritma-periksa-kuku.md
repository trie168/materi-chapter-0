# Algoritma /Pseudocode Challenge - Periksa Kuku

## Problem

Seorang guru akan memeriksa kuku siswa-siswinya yang sebanyak 40 orang dengan cara berkeliling kelas. Jika guru menemukan siswa/siswi yang memiliki kuku yang panjang maka guru akan menghukum siswa/siswi tersebut, jika tidak guru akan memuji siswa/siswi tersebut.

Buatlah algoritma/pseudocode untuk permasalahan diatas.

//your algorithm / pseudocode here
