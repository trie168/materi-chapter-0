# Challenge !! Cek Angka

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama cekAngka. <br>
Function tsb akan menerima dua buah parameter number, kemudian cek apabila di parameter pertama ada angka yang berurutan 3x, memiliki angka yang sama berurutan 2x di parameter kedua.<br>
Contohnya : input "1212111223" dan "1211445", menghasilkan true karena di parameter pertama ada "111" dan di parameter kedua didapatkan "11"
3. Kirim hasil code kamu dengan gist, dengan nama file : cekAngka.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
