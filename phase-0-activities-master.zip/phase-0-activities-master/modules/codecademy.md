# Challenge !! Codecademy javascript

## Tugas
1. Buka link [codecademy JavaScript  lesson berikut ini](https://www.codecademy.com/learn/javascript)
2. Register kemudian selesaikan codecademy di atas dari unit 1 - 8
3. Share account kamu untuk di cek oleh instructor kamu yang sedang in charge via slack (contohnya : https://www.codecademy.com/rizafahmi)
