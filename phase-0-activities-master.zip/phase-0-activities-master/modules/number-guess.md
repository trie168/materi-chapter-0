# Create a Number Guessing Game

## Objectives

- ▢ Melatih logika sederhana.

## Directions

- ▢ Buat variabel yang akan berisi jawaban dengan angka acak (misalnya antara 1 sampai 10).
- ▢ Beri batas kesempatan pada pemain untuk menebak angka (misalnya 5 kali).
- ▢ Setiap tebakan di-submit, beri tahu apakah tebakannya lebih besar atau lebih kecil dari angka jawaban.
- ▢ Kurangi jumlah kesempatan setiap melakukan tebakan.
- ▢ Kasih "selamat atas kemenanganmu" pada pemain jika tebakannya betul. Jika kesempatan sudah habis, beritahu jawabannya sambil bilang bahwa pemain "kurang beruntung".

## Submissions

- ▢ Buatlah aplikasi tersebut dalam halaman `number-guess.html` atau `number-guess.js` pada repo website kamu.
- ▢ Commit dan push file tersebut ke GitHub.
- ▢ Share hasil kamu di Slack.
