# Challenge !! Jenis Bilangan

## Objectives

Seperti yang sudah kita ketahui, bahwa ada beberapa jenis bilangan, yaitu : ganjil, genap, prima, bulat, rasional, dll.

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buatlah sebuah function dengan nama jenisBilangan untuk menampilkan angka 1 sampai 100 ke bawah, dan di samping nya terdapat keterangan jenis bilangan tersebut.
3. Setelah selesai, kirim hasil code kamu dengan gist, dengan nama file : jenisBilangan.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.

## Expected Output
Ketika function dipanggil, akan menghasilkan data sbb :

1 adalah bilangan ganjil

2 adalah bilangan prima

3 adalah bilangan prima

4 adalah bilangan genap

... dan seterusnya sampai 100
