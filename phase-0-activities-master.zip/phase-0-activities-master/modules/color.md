# Color

## References

- [Social Media Colours – Hex and RGB Colours of the Web](http://designpieces.com/2012/12/social-media-colours-hex-and-rgb)
