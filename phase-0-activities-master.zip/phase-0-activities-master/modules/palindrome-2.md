# Challenge !! Palindrome 2

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama palindromeCont. <br>
Sebelumnya kita pernah membuat function palindrome namun input nya hanya sebuah string. Kali ini buatlah sebuah function yang menerima input berupa kalimat, kemudian mendeteksi apakah palindrome atau bukan.
Contohnya : input "Aku suka rajawali, bila wajar aku suka" menghasilkan true
3. Kirim hasil code kamu dengan gist, dengan nama file : palindromeCont.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
