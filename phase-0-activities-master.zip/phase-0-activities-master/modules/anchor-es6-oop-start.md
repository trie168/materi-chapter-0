# Membuat ES6 Class Sederhana

## Objectives

- Mampu memanfaatkan Class pada ES6 untuk membangun object JavaScript

## Directions

1. Ubah kasus dibawah ini ke dalam bentuk ES6 Class.

### Tugas

Buatlah sebuah Class Mobil, yang memiliki atribut berikut:
- Merek,
- Harga,
- Warna,
- Bensin, dan
- Jumlah Roda.

Class tersebut juga bisa memanggil function dengan proses sebagai berikut:
- tampilkanSpesifikasi: menampilkan melalui console.log merek, harga, warna, bensin, dan jumlah roda dengan format berikut:

"Mobil saya bermerek Hando dengan harga 300000000 rupiah, berwarna merah, bensinnya solar, dan beroda 4".

- jualMobil: menampilkan melalui console.log harga mobil yang dikurangi 20%.
