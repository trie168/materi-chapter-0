# Challenge !! Order String

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama orderString. Function tsb akan menerima sebuah parameter string, kemudian menghasilkan string kembali dengan urutan huruf yang sesuai. Contoh nya, parameter = "matahari", maka outputnya adalah aaahimrt
3. Kirim hasil code kamu dengan gist, dengan nama file : orderString.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
