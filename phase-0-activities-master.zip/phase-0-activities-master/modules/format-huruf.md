# Challenge !! Format Huruf

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama formatHuruf. Function tsb akan menerima sebuah parameter string dengan format campuran dari huruf besar dan huruf kecil, kemudian menghasilkan string kembali dengan format huruf yang berkebalikan. Contoh nya, parameter = "MataHari PaGi", maka outputnya adalah "mATAhARI pAgI"
3. Kirim hasil code kamu dengan gist, dengan nama file : formatHuruf.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
