# Play Codewars

## Objectives

Codewars merupakan tempat berlatih programming yang sangat menantang. Kita dapat meningkatkan skill dengan menyelesaikan berbagai tantangan code yang nyata. Anggaplah ini sebagai _having challenges_ yang relevan bagimu di samping materi JavaScript yang lain.

## Directions

- ▢ [Kunjungi Codewars untuk mulai bergabung](http://www.codewars.com/r/0OfMJg).
- ▢ Pilih skill JavaScript lalu buktikan bahwa kamu mampu melalui babak kualifikasi yang terdiri dari tiga soal mudah.
- ▢ Setelah berhasil masuk, mulailah _Training_ kamu.
