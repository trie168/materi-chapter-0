# Challenge !! Array 1

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama array1. <br>
Function tsb akan menerima sebuah parameter array, kemudian cek apakah jumlah semua angka (selain angka maksimal) di dalam array tersebut lebih kecil atau sama dari angka maksimalnya. Apabila ya, akan mengembalikan true.
Contohnya : array 1,2,3,4,5,15 menghasilkan true karena 1+2+3+4+5 <= 15
3. Kirim hasil code kamu dengan gist, dengan nama file : array1.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
