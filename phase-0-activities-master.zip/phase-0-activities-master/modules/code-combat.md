# Play Some Code Combat

## Objectives

Code Combat merupakan permainan belajar programming yang multiplayer. Anggaplah ini sebagai _having fun_ yang relevan bagimu di samping materi serius JavaScript yang lain.

## Directions

- ▢ Kunjungi <https://codecombat.com/courses?_cc=SwordNiceSpoon>, lalu sign up sebuah akun agar dapat bergabung di Hacktiv8 Course
- ▢ Pilih hero kamu, lalu mainkan berbagai level yang ada.
