# Challenge !! Range Angka

Baca dan pahami tentang Js recursion : https://www.sitepoint.com/recursion-functional-javascript/

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama range. Pastikan untuk menggunakan metode recursion! Penggunaan looping for,while, dll tidak diperbolehkan. <br>
Function tsb akan menerima dua buah parameter number, kemudian tampilkanlah range angka dari kedua number tsb.<br>
Contohnya : input angka 2 dan 20, maka hasilnya adalah angka 3 sampai 19.
3. Kirim hasil code kamu dengan gist, dengan nama file : rangeAngka.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
