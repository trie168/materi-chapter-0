# Challenge !! Cek String

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama cekString. <br>
Function tsb akan menerima dua buah parameter string, kemudian cek apakah string ke 2 dapat dibuat dari string ke 1.
Contohnya : cekString("abcdefghijklmno", "matahari") hasilnya false
cekString("aaawossrld", "world") hasilnya true
cekString("aaawossrld", "worldd") hasilnya false, karena huruf d ada 2 di parameter kedua
3. Kirim hasil code kamu dengan gist, dengan nama file : cekString.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
