# Challenge !! Angka Pangkat

Baca dan pahami tentang Js recursion : https://www.sitepoint.com/recursion-functional-javascript/

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama pangkat. Pastikan untuk menggunakan metode recursion! <br>
Function tsb akan menerima dua buah parameter number, kemudian tampilkan hasil dari bilangan pertama pangkat bilangan kedua.<br>
Contohnya : input angka 8 dan 4, maka hasilnya adalah 4096.
3. Kirim hasil code kamu dengan gist, dengan nama file : pangkat.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
