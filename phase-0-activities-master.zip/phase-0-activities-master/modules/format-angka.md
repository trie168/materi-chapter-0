# Challenge !! Format Angka

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama formatAngka. Function tsb akan menerima 2 buah parameter number, dimana parameter pertama harus lebih besar dari parameter kedua. Apabila parameter pertama lebih kecil, maka function akan menghasilkan error message.
Function ini akan mengkonversi hasil bilangan pertama dibagi bilangan kedua, dan menformatnya. Contohnya : formatAngka(250000, 100), menjadi 2,500
3. Kirim hasil code kamu dengan gist, dengan nama file : formatAngka.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
