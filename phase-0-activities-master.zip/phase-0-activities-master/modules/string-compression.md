# Challenge !! String Compression

## Objectives

String Compression adalah menghitung jumlah huruf yang muncul dalam suatu string. Misalnya : aaaabbcddddddee, maka string compression nya adalah : a4, b2, c1, d6, e2

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buatlah sebuah function dengan nama stringCompression yang menerima input string, kemudian olah string tersebut agar menghasilkan string compresion
3. Setelah selesai, kirim hasil code kamu dengan gist, dengan nama file : stringCompression.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.

## Input
honda beat dan yamaha mio

## Expected Output
Ketika function dipanggil, akan menghasilkan data sbb :

String Compression dari kalimat : honda beat dan yamaha mio adalah :
a6
b1
d2
e1
h2
i1
m2
n2
o2
t1
y1
