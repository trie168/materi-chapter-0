# Challenge !! Cek Bilangan Prima

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama cekBilanganPrima. <br>
Function tsb akan menerima sebuah parameter number, kemudian cek apabila parameter tersebut adalah bilangan prima, maka menghasilkan boolean true. Apabila sebaliknya, akan menghasilkan false
3. Kirim hasil code kamu dengan gist, dengan nama file : cekBilanganPrima.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
