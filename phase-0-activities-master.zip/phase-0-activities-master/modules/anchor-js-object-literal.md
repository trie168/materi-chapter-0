# Menggunakan Object Literal

## Objectives

1. Mengerti Cara Membuat Object dengan Object literal

## Directions

Merujuk ke soal [Menyusun Class ES6 Lanjutan](/modules/anchor-es6-oop.md), buatlah object dengan object literal dengan bentuk yang serupa dengan object yang dibuat oleh class yang kita buat di tugas tersebut!
