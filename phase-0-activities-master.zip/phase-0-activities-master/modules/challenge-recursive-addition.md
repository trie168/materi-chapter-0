# Logic Challenge - Recursive Addition

## Problem

Have the function recursiveAddition(num) add up all the numbers from num to 1. For example: if the input is 4 then your program should return 10 because 4 + 3 + 2 + 1 = 10.

## Code

```JavaScript
function recursiveAddition(num) {
  // you can only write your code here!
}

// TEST CASES
console.log(recursiveAddition(4)); // 10
console.log(recursiveAddition(5)); // 15
console.log(recursiveAddition(3)); // 6
console.log(recursiveAddition(1)); // 1
console.log(recursiveAddition(6)); // 21
```
