# Choose Your Text and Code Editor

## References

- [Dev Series: 5 text editor modern untuk pengembang aplikasi](https://id.techinasia.com/developer-series-5-text-editor-modern)
