# Beautifying and Checking Code Quality

## Objectives

- Mengecek kualitas kode dengan hinting/linting

## Directions

###

Buatlah sekumpulan code JavaScript (bebas), boleh pakai dari hasil code yang dibuat dari berbagai tantangan terdahulu. Lalu copy paste code tersebut ke dalam hinter/linter seperti [JSHint](http://jshint.com) atau [JSLint](http://jslint.com)

## Mempercantik susunan sintaks code JavaScript ataupun HTML

- [JS Beautifier](http://jsbeautifier.org)
