# Challenge !! Konversi Waktu

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama konversiWaktu yang menerima sebuah parameter. Function tsb akan mengkonversi jumlah parameter menjadi jumlah jam dan menit. Contoh nya, parameter = 73, maka outputnya adalah 1:13. Pisahkan antara jam dan menit oleh karakter ":"
3. Kirim hasil code kamu dengan gist, dengan nama file : konversiWaktu.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
