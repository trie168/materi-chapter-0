# Challenge !! Separate Number

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama separateNumber. Function tsb akan menerima sebuah parameter string, isinya nomor dengan dengan jumlah digit 10-16, kemudian menghasilkan string kembali dengan ketentuan : setiap angka ganjil berdampingan, maka dipisahkan oleh "-", dan angka 0 tidak dianggap sebagai angka ganjil. Contohnya, parameter : "9113020675971081" menjadi "9-1-1-302067-5-9-7-1081"
3. Kirim hasil code kamu dengan gist, dengan nama file : separateNumber.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
