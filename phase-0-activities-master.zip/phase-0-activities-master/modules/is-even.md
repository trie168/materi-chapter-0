# Challenge !! Angka Ganjil

Baca dan pahami tentang Js recursion : https://www.sitepoint.com/recursion-functional-javascript/

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama isEven. Pastikan untuk menggunakan metode recursion! <br>
Function tsb akan menerima sebuah parameter number, kemudian tampilkan true apabila angka tersebut ganjil.<br>
Contohnya : input angka 9, maka hasilnya adalah true.
3. Kirim hasil code kamu dengan gist, dengan nama file : isEven.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
