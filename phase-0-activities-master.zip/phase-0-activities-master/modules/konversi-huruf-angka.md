# Challenge !! Konversi Huruf dan Angka

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama konversiHurufAngka. <br>
Function tsb akan menerima sebuah parameter string, kemudian konversi setiap huruf ke angka dan setiap angka ke huruf dengan range 1 - 26 saja.<br>
Contohnya : input "m4t4h4ri", menghasilkan "13d20d8d189"
3. Kirim hasil code kamu dengan gist, dengan nama file : konversiHurufAngka.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
