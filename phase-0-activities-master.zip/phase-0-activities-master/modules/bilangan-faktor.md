# Challenge !! Bilangan Faktor

## Objectives

Faktor suatu bilangan adalah suatu bilangan yang merupakan kelipatan dari bilangan tersebut. Contohnya faktor bilangan dari angka 18 adalah 1, 2, 3, 6, 9, dan 18

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buatlah sebuah function dengan nama bilanganFaktor yang menerima input integer, kemudian olah integer tersebut agar mengembalikan bilangan faktor.
3. Setelah selesai, kirim hasil code kamu dengan gist, dengan nama file : bilanganFaktor.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.

## Input
bilangan apa saja

## Output
Ketika function dipanggil dengan parameter 18, akan menghasilkan data sbb :

1, 2, 3, 6, 9, 18
