# Algoritma /Pseudocode Challenge - Laundry Day

## Problem

Foxie akan mencuci pakaiannya menggunakan mesin cuci. Pakaian yang akan dicuci oleh Foxie sebanyak 20 dan akan dimasukkan ke mesin cuci.
Mesin cuci akan dinyalakan jika semua pakaian Foxie sudah masuk ke mesin cuci.

Bantulah Foxie untuk menghitung jumlah pakaian yang akan dimasukkan ke mesin cuci menggunakan algoritma / pseudocode perulangan.

//your algorithm / pseudocode here
