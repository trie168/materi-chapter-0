# Challenge !! Pola Angka

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama polaAngka. <br>
Kali ini kita akan mendeteksi 4 buah pola angka, yaitu "ditambah x" / "dikurang x" / "dikali x" / "dibagi x"<br>
Function tsb akan menerima sebuah parameter array, kemudian deteksi pola angka di dalam array tsb.
Contohnya : input "[1,3,5,7]", menghasilkan "pola angka : ditambah 2".<br>
input "[1,3,9,27]", menghasilkan "pola angka : dikali 3".<br>
apabila pola angka bukan ditambah / dikurang / dikali / dibagi, maka menghasilkan "pola angka tidak ada."
3. Kirim hasil code kamu dengan gist, dengan nama file : polaAngka.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
