# Challenge !! Repeated Letter

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama repeatedLetter. <br>
Function tsb akan menerima sebuah parameter string, kemudian cari sebuah kata yang mengandung jumlah variasi perulangan huruf paling banyak.
Contohnya : input "Indahnya matahari di pagi ini" menghasilkan "Indahnya" karena memiliki variasi huruf yang berulang paling banyak, yaitu "n" dan "a"
3. Kirim hasil code kamu dengan gist, dengan nama file : repeatedLetter.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
