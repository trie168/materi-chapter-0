# Challenge !! Sum Array

Baca dan pahami tentang Js recursion : https://www.sitepoint.com/recursion-functional-javascript/

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama sumArray. Pastikan untuk menggunakan metode recursion! <br>
Function tsb akan menerima sebuah parameter array, kemudian jumlahkan semua angka di dalam array tsb.<br>
Contohnya : input [1,2,3,4,5,6], maka hasilnya adalah 21.
3. Kirim hasil code kamu dengan gist, dengan nama file : sumArray.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
