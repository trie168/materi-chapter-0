# Challenge !! Faktor Prima

## Objectives

Faktor prima adalah faktor-faktor suatu bilangan berbentuk bilangan prima. Faktorisasi prima merupakan perkalian dari semua faktor-faktor primanya.

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buatlah sebuah function dengan nama faktor_prima yang menerima input integer, kemudian olah integer tersebut agar mengembalikan bilangan faktor.
3. Setelah selesai, kirim hasil code kamu dengan gist, dengan nama file : faktorPrima.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.

## Input
bilangan apa saja

## Output
Ketika function dipanggil dengan parameter 12, akan menghasilkan data sbb :

2 pangkat 2

3 pangkat 1

Cobalah dengan memasukkan parameter lain, seperti 42, 84, 200, dll
