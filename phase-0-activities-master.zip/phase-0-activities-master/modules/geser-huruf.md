# Challenge !! Pergeseran Huruf

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama geserHuruf. <br>
Function tsb akan menerima dua buah parameter string dan number, kemudian konversi huruf tersebut dengan menggeser urutannya sebanyak n.
Contohnya : input "Matahari Pagi" dan "4", menghasilkan "Qexelevm Tekm".<br>
Input "wxyz" dan "4", menghasilkan "abcd"
3. Kirim hasil code kamu dengan gist, dengan nama file : geserHuruf.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
