# Challenge !! Index Bilangan Prima

## Tugas
1. Bukalah sebuah tools online untuk menuliskan code JavaScript
2. Buat sebuah function bernama indexPrima. <br>
Function tsb akan menerima sebuah parameter number, kemudian menghasilkan angka prima dengan urutan ke -x (sesuai yang diinput). <br>
Contohnya : indexPrima(4) akan menghasilkan 7
3. Kirim hasil code kamu dengan gist, dengan nama file : indexPrima.js. Share gist kamu melalui private message slack ke instructor yang sedang in charge.
